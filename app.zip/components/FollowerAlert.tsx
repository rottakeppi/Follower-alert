import { motion } from 'motion/react';
import { useEffect, useState } from 'react';
import { Heart } from 'lucide-react';

interface FollowerAlertProps {
  followerName: string;
  onComplete: () => void;
}

export function FollowerAlert({ followerName, onComplete }: FollowerAlertProps) {
  const [show, setShow] = useState(false);

  useEffect(() => {
    // Trigger animation on mount
    setShow(true);

    // Auto-hide after 5 seconds
    const timer = setTimeout(() => {
      setShow(false);
      setTimeout(onComplete, 500); // Wait for exit animation
    }, 5000);

    // Optional: Play sound effect here
    // new Audio('/path-to-sound.mp3').play();

    return () => clearTimeout(timer);
  }, [onComplete]);

  if (!show) return null;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.5, y: -100 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.5, y: -100 }}
      transition={{ 
        type: "spring", 
        stiffness: 260, 
        damping: 20,
        duration: 0.6 
      }}
      className="fixed top-20 left-1/2 -translate-x-1/2 z-50"
    >
      <div className="relative flex items-center justify-center gap-4 bg-gradient-to-r from-gray-900 via-slate-800 to-gray-900 px-12 py-8 rounded-2xl shadow-2xl border border-slate-600/50 backdrop-blur-sm">
        
        {/* Animated Heart Icon */}
        <motion.div
          initial={{ scale: 0, rotate: -180 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ 
            delay: 0.2,
            type: "spring",
            stiffness: 300,
            damping: 15
          }}
          className="absolute left-8 top-1/2 -translate-y-1/2"
        >
          <motion.div
            animate={{
              scale: [1, 1.2, 1],
            }}
            transition={{
              duration: 1.5,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            <Heart className="w-12 h-12 fill-cyan-400 text-cyan-400 drop-shadow-[0_0_15px_rgba(6,182,212,0.8)]" />
          </motion.div>
        </motion.div>

        {/* Text Animation */}
        <div className="flex flex-col gap-1 text-center pl-12">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3, duration: 0.5 }}
            className="text-4xl font-bold text-white flex items-baseline gap-2 justify-center"
          >
            <motion.span
              animate={{
                color: ['#ffffff', '#06b6d4', '#ffffff']
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut"
              }}
            >
              {followerName}
            </motion.span>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.5, duration: 0.5 }}
            className="text-2xl text-cyan-300 font-semibold"
          >
            is now following!
          </motion.div>
        </div>

        {/* Particles effect */}
        {[...Array(6)].map((_, i) => (
          <motion.div
            key={i}
            initial={{ 
              opacity: 1, 
              scale: 0,
              x: 0,
              y: 0
            }}
            animate={{ 
              opacity: 0, 
              scale: 1,
              x: Math.cos((i * Math.PI) / 3) * 100,
              y: Math.sin((i * Math.PI) / 3) * 100
            }}
            transition={{
              duration: 1.5,
              delay: 0.3 + i * 0.1,
              ease: "easeOut"
            }}
            className="absolute w-2 h-2 bg-cyan-400 rounded-full"
            style={{
              left: '50%',
              top: '50%',
            }}
          />
        ))}
      </div>
    </motion.div>
  );
}