import { useState, useEffect } from 'react';
import { FollowerAlert } from './components/FollowerAlert';

export default function App() {
  const [currentFollower, setCurrentFollower] = useState<string | null>(null);

  const handleAlertComplete = () => {
    setCurrentFollower(null);
  };

  // Listen for messages from Twitch/StreamElements/Streamlabs webhook
  // You can trigger alerts by sending messages to this window
  // Example: window.postMessage({ type: 'follower', name: 'Username' }, '*');
  
  // For testing, you can open browser console and run:
  // window.postMessage({ type: 'follower', name: 'TestUser' }, '*');
  
  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      if (event.data?.type === 'follower' && event.data?.name) {
        setCurrentFollower(event.data.name);
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  return (
    <div className="size-full bg-transparent">
      {/* Follower Alert Overlay - Transparent background for OBS */}
      {currentFollower && (
        <FollowerAlert 
          followerName={currentFollower} 
          onComplete={handleAlertComplete}
        />
      )}
    </div>
  );
}